package giftCardproj;

import java.awt.*;
import java.awt.event.*;
// import javax.swing.*;
import java.sql.*;


class UserFrame extends Frame implements ActionListener{
	
	Label lblTitle, lblCustomerNo, lblCardNo, lblBalance, lblStatus ;
	TextField txtCustomerNo, txtCardNo, txtBalance;
	Button btnApplyPayment, btnClear;
	
	String qry = "";
	Connection con = null;
	PreparedStatement st = null;
	ResultSet rs = null;
	Statement stmt = null;
	
	// Data Connection 
	public void connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/giftcardproj?characterEncoding=utf8";
			String username = "root";
			String password = "root";
			con = DriverManager.getConnection(url, username, password );
			System.out.println("Connected to the database");
		} catch(ClassNotFoundException e) {
			System.out.println("Could not find the database driver :" + e.getMessage());
		} catch(SQLException ex) {
			System.out.println("Failed to connect to the database : " + ex.getMessage());
		}
	}
	
	// Clear from Details
	public void clear() {
		txtCustomerNo.setText("");
		txtCardNo.setText("");
		txtBalance.setText("");
		txtCustomerNo.requestFocus();
	}

	public UserFrame() {
		connect();
		this.setVisible(true);
		this.setSize(1000,600);
		this.setTitle("Redeem Gift Card");
		this.setLayout(null);
		Color formColor = new Color(53, 59, 72);
		this.setBackground(formColor);
		
		Font titleFont = new Font("arial", Font.BOLD, 25);
		Font labelFont = new Font("arial", Font.PLAIN, 18);
		Font textFont = new Font("arial", Font.PLAIN, 18);
		
		// Set Title 
		
		lblTitle = new Label("Enter a Redeem Code");
		lblTitle.setBounds(250, 40, 400, 50);
		lblTitle.setFont(titleFont);
		lblTitle.setForeground(Color.YELLOW);
		add(lblTitle);
		
		// Set Customer No
		
		lblCustomerNo = new Label("Customer No   : ");
		lblCustomerNo.setBounds(250, 110, 150, 30);
		lblCustomerNo.setFont(labelFont);
		lblCustomerNo.setForeground(Color.WHITE);
		add(lblCustomerNo);
		
		txtCustomerNo = new TextField();
		txtCustomerNo.setBounds(400, 110, 400, 30);
		txtCustomerNo.setFont(textFont);
		txtCustomerNo.addActionListener(this);
		add(txtCustomerNo);
		
		// Set Card No
		
		lblCardNo = new Label("Card No          : ");
		lblCardNo.setBounds(250, 180, 150, 30);
		lblCardNo.setFont(labelFont);
		lblCardNo.setForeground(Color.WHITE);
		add(lblCardNo);
		
		txtCardNo = new TextField();
		txtCardNo.setBounds(400, 180, 400, 30);
		txtCardNo.setFont(textFont);
		txtCardNo.addActionListener(this);
		add(txtCardNo);
		
		// Set Balance
		
		lblBalance = new Label("Balance          : ");
		lblBalance.setBounds(250, 250, 150, 30);
		lblBalance.setFont(labelFont);
		lblBalance.setForeground(Color.WHITE);
		add(lblBalance);
		
		txtBalance = new TextField();
		txtBalance.setBounds(400, 250, 400, 30);
		txtBalance.setFont(textFont);
		txtBalance.addActionListener(this);
		add(txtBalance);
		
		// Button
		
		btnApplyPayment = new Button("Apply Payment");
		btnApplyPayment.setBounds(400, 330, 200, 30);
		btnApplyPayment.setBackground(Color.BLUE);
		btnApplyPayment.setForeground(Color.WHITE);
		btnApplyPayment.setFont(labelFont);
		btnApplyPayment.addActionListener(this);
		add(btnApplyPayment);
		
		btnClear = new Button("Clear");
		btnClear.setBounds(620, 330, 185, 30);
		btnClear.setBackground(Color.RED);
		btnClear.setForeground(Color.WHITE);
		btnClear.setFont(labelFont);
		btnClear.addActionListener(this);
		add(btnClear);
		
		// Status Valid or Not
		
		lblStatus = new Label("-------------------");
		lblStatus.setFont(labelFont);
		lblStatus.setForeground(Color.WHITE);
		lblStatus.setBounds(400, 380, 300, 30);
		add(lblStatus);
		
		
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		try {   
			
			String CustomerNo = txtCustomerNo.getText();
			String CardNo     = txtCardNo.getText();
			String Balance    = txtBalance.getText();
			
			if(e.getSource().equals(btnClear)) {
			clear();
	    	}
			else if(e.getSource().equals(btnApplyPayment)) 
				
				
				if(!CustomerNo.isEmpty() && CustomerNo != null ) {
					
					// Save Details
					String qry = "insert into giftcardproj (CustomerNo, CardNo, Balance) values(?,?,?)";
					PreparedStatement st = con.prepareStatement(qry);
					st.setString(1, CustomerNo);
					st.setString(2, CardNo );
					st.setString(3, Balance);
					st.executeUpdate();
					clear();
					lblStatus.setText("The card is valid");
				}
			
			else {
				lblStatus.setText("Enter a Card Details");
			}
				}
			catch(Exception ex) {
			System.out.println("Failed to connect to the database : " + ex.getMessage());
		} 
	}
}
 
public class Giftcard {

	public static void main(String[] args) {
		UserFrame frm = new UserFrame();

	}
}

