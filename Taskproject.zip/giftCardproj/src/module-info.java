/**
 * 
 */
/**
 * 
 */
module giftCardproj {
	requires java.desktop;
	requires java.sql;
	
}